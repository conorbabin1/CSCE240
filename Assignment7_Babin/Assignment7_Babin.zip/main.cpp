#include <cstdio>
#include <iostream>
#include "linkedList.h"
#include "node.h"
#include "linkedList.cpp"
#include "node.cpp"
#include "linkedList.h"
#include <ctime>
#include <stdlib.h>

using namespace std;



int main (int argc, char **argv)
{ 

	time_t begin,end;
        time(&begin);
        linkedList<int> list1;
        time(&end);
        double sec_elapsed = (difftime(end, begin));
        cout.precision(10);
	cout.setf(ios::fixed);
        cout << "Time elapsed for creation: " << sec_elapsed<< endl;

	int i = 0;
        time(&begin);
     	while(i < 100000000){
		list1.insert(i, 0);
		i++;
	}
        time(&end);
        sec_elapsed = (difftime(end, begin));
	i = 0;
	time(&begin);
	while(i < 100000000){
		i++;
	}
	time(&end);
	double whileTime = (difftime(end, begin));
        cout.precision(10);
        cout << "Time elapsed for insertion: " << sec_elapsed - whileTime << endl;


	i = 0;
        time(&begin);
        while(i < 100000000){
                list1.remove(0);

                i++;
        }
        time(&end);
        sec_elapsed = (difftime(end, begin));
        i = 0;
        time(&begin);
        cout.precision(10);
        cout << "Time elapsed for removal: " << sec_elapsed - whileTime << endl;
	
	i = 0;
	while(i < 1000){
                list1.insert(i, 0);
                i++;
        }

	i = 0;
        time(&begin);
        while(i < 1000000){
                list1.search(i);
        	i++;
        }
        time(&end);
        sec_elapsed = (difftime(end, begin));
        i = 0;
        time(&begin);
        cout.precision(10);
        cout << "Time elapsed for searching: " << sec_elapsed - whileTime << endl;
	
	i = 0;
        time(&begin);
        while(i < 1000000){
                list1.read(500);
                i++;
        }
        time(&end);
        sec_elapsed = (difftime(end, begin));
        i = 0;
        time(&begin);
        cout.precision(10);
        cout << "Time elapsed for reading: " << sec_elapsed - whileTime << endl;




    return 0;
}


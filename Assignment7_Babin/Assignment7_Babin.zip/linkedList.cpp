/*
 * Created by: Conor Babin
 * Thur Nov 13 15:07:14 EDT 2017
 * input: *
 * output: Version of LinkedList
 * File: linkedList.cpp
*/

#include <iostream>
#include <cstdlib>
#include "linkedList.h"
#include "node.h"
template <class T>
linkedList<T>::linkedList(){
	setHead(NULL);
	count = 0;
}
template <class T>
linkedList<T>::~linkedList(){
	Node<T>* current = getHead();
	if(!(current)){

	}
	else{
		int i = 0;
		while(i < count){
			Node<T>* temp = current->getNext();
			delete current;
			current = temp;
			i++;
		}
	}
}
//inserts a node at a given index
//input: value to populate the node and the index to insert it at
template <class T>
void linkedList<T>::insert(T _value, int index){
	if(index < 0 || index > count){
		cout << "Index out of bounds" << endl;
		return;
	}
	Node<T>* node1 = new Node<T>(_value);
	int i = 0;
	Node<T>* temp1 = getHead();
	
	if(!(getHead())){
		setHead(node1);
	}
	else if(index == 0){
		node1->setNext(getHead());
		setHead(node1);
	}
	else if(index == count - 1){
		i = 0;
		while(i < index){
			temp1 = temp1->getNext();
			i++;	
		}
		temp1->setNext(node1);
		node1->setNext(NULL);
	}
	else{
		temp1 = getHead();
		Node<T>* temp2 = getHead();
		i = 0;
		while(i < index){
			temp1 = temp1->getNext();
			i++;
		}
		temp2 = temp1->getNext();
		node1->setNext(temp2);
		temp1->setNext(node1);
	}
	addCount();
}
//removes a node at a given index
//input: index to remove from
template <class T>
void linkedList<T>::remove(int index){
	if(index < 0 || index >= count){
		cout << "Index out of bounds" << endl;
		return;
	}
	int i = 0;
	Node<T>* temp1 = getHead();
	if(!(getHead())){
		cout << "Empty list" << endl;
		return;
	}
	else if(index == 0){
		setHead(getHead()->getNext());
		delete temp1;
	}
	else if(index == count - 1){
		while(i < index - 1){
			temp1 = temp1->getNext();
			i++;
		}
		Node<T>* temp = temp1->getNext();
		delete temp;
		temp1->setNext(NULL);
	}
	else{
		temp1 = getHead();
		Node<T>* temp2 = getHead();
		Node<T>* temp3 = getHead();
		i = 0;
		while(i < index - 1){
			temp1 = temp1->getNext();
			i++;
		}	
		temp2 = temp1->getNext();
		temp3 = temp2->getNext();
		delete temp2;
		temp1->setNext(temp3);	
	}
	subCount();
}
//finds the index of the first example of a node with the given value
//input: a value to search for
//output: index of the first node with the given value
template <class T>
int linkedList<T>::search(T _value) const{
	Node<T>* temp = getHead();
	int i = 0;
	while(i < count){
		if(temp->getValue() == _value){
			return i;
		}
		temp = temp->getNext();
		i++;
	}
	return -1;
}
//gives the value at a given index
//input: index to read from
//output: value fo the node at the given index
template <class T>
T linkedList<T>::read(int index) const{
	if(index < 0 || index > count){
		cout << "Read index out of bounds" << endl;
		return head->getValue();
	}
	Node<T>* temp = getHead();
	int i = 0;
	while(i < index){
		temp = temp->getNext();
		i++;
	}
	return temp->getValue();
}
//prints the value of every node
template <class T>
void linkedList<T>::print() const{
	if(!(getHead())){
		cout << endl;
		return;
	}
	Node<T>* temp = getHead();
	int i = 0;
	do{
		cout << temp->getValue() << " ";
		temp = temp->getNext();
		i++;
	}while(temp->getNext());
}
template <class T>
void linkedList<T>::setHead(Node<T>* _head){
	head = _head;
}
template <class T>
Node<T>* linkedList<T>::getHead() const{
	return head;
}
template <class T>
void linkedList<T>::addCount(){
	count++;
}
template <class T>
void linkedList<T>::subCount(){
	count--;
}


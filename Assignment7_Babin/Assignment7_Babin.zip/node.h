#ifndef NODE_H
#define NODE_H
#include <iostream>


using namespace std;
template <class T>
class Node
{
public:
	Node();
	Node(T);
	Node(T, Node*);
	Node(const Node& orig);
	~Node();

	void print() const;
	void setValue(T);
	void setNext(Node*);
	T getValue() const;
	Node* getNext() const;

private:
	T value;
	Node* next;
};

#endif

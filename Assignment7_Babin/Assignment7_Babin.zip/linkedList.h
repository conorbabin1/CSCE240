#ifndef LINKEDLIST_H
#define LINKEDLIST_H
#include <iostream>
#include "node.h"


using namespace std;
template <class T>
class linkedList
{
public:
	linkedList();
	~linkedList();
	
	void insert(T, int index);
	void remove(int index);
	int search(T) const;
	T read(int index) const;
	void print() const;
	void setHead(Node<T>*);
	Node<T>* getHead() const;

private:
	Node<T>* head;
	int count;
	void addCount();
	void subCount();
};

#endif

/*
 * Created by: Conor Babin
 * Thur Nov 13 15:07:14 EDT 2017
 * input: *
 * output: Node that makes up a linkedList
 * File: node.cpp
*/

#include <iostream>
#include <cstdlib>
#include "node.h"
template <class T>
Node<T>::Node(){
	setValue(0);
	setNext(NULL);
}
template <class T>
Node<T>::Node(T _value){
	setValue(_value);
	setNext(NULL);
}
template <class T>
Node<T>::Node(T _value, Node* _next){
	setValue(_value);
	setNext(_next);
}
template <class T>
Node<T>::Node(const Node& orig){
	setValue(orig.getValue());
	setNext(orig.getNext());
}
template <class T>
Node<T>::~Node(){
	
}
//prints the value and next nodes adress
template <class T>
void Node<T>::print() const{
	cout << getValue() << endl;
	cout << getNext() << endl;
}
//sets the value of the node to a given value
//input: value to set the node to
template <class T>
void Node<T>::setValue(T _value){
	value = _value;
}
//sets the address of the next node
//input: the address of the next node
template <class T>
void Node<T>::setNext(Node* _next){
	next = _next;
}
//returns the value
//output: current value of the node
template <class T>
T Node<T>::getValue() const{
	return value;
}
//returns the address of the next node
//output: a node pointer to the address of the next node
template <class T>
Node<T>* Node<T>::getNext() const{
	return next;
}


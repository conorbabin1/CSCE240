/***************************************************************************
 * myArray class header file
 ***************************************************************************/
#ifndef ARRAY_H
#define ARRAY_H
#include <iostream>


using namespace std;

template <class T>
 
class myArray
{
	template <class U>
	friend ostream & operator<<(ostream&, const myArray<U>&);
	template <class U>
        friend istream & operator>>(istream&, myArray<U>&);

	public: 
		myArray();
		myArray(int, T); 
		myArray(T*, int);
		myArray(const myArray&);
		~myArray();

		void setArr(int, T);
                int getSize() const;
                T getArr(int) const;
		void insert(int, T);
		void remove(int);
		T get(int) const;
		void clear();
		int find(T) const;
		bool equals(T&) const;
		void print() const;
		void init();
		myArray<T>& operator=(const myArray<T>&);
		bool operator==(const myArray<T>&) const;
		bool operator!=(const myArray<T>&) const;
		const myArray<T> operator+(const myArray<T>&) const;
		const myArray<T> operator-();
		const myArray<T>& operator++();
		const myArray<T> operator++(int);
		T& operator[](int);
		
		
	private: 
		int size; 
		T *arr; 
		void setSize(int);
	
};

#endif

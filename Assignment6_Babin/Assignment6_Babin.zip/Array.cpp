/*
 * Created by: Conor Babin
 * Thur Nov 2 15:07:14 EDT 2017
 * input: *
 * output: Version of ArrayList
 * File: Array.cpp
*/

#include <iostream>
#include <cstdlib>
#include "Array.h"

template <class T>

//default constructor
myArray<T>::myArray() : size(0){
	arr = new T[size];
}
template <class T>
//alt constructor
//input: Array size and value to be populated
myArray<T>::myArray(int _size, T num) : size(_size) {
	arr = new T[size];
	int i = 0;
	while(i < size){
		arr[i] = num;
		i++;
	}
}
template <class T>

//alt constructor
//input: pointer for Array and size of the array
myArray<T>::myArray(T *_arr, int _size) : size(_size) {
	arr = new T[size];
	int i = 0;
	while(i < size){
		arr[i] = _arr[i];
		i++;
	}
}
template <class T>
//copy constructor
//input: myArray to copy
myArray<T>::myArray(const myArray& orig) {
    setSize(orig.getSize());
    arr = new T[getSize()];
    for (int i = 0; i < getSize(); i++) {
        setArr(i, orig.getArr(i));
    }
}
template <class T>
//deconstructor
myArray<T>::~myArray() {
	delete [] arr;
}
template <class T>
//gets given index of the array
//input: index
//output: value of the array at given index
T myArray<T>::getArr(int index) const{
	if((index >= 0) && (index < size)){
		return arr[index];
	}
	else{
		cout << "Array out of Bounds" << endl;
		return arr[getSize() -1];
	}
}
template <class T>
//gets the size of the array
//output: size of the array
int myArray<T>::getSize() const{
	return size;
}
template <class T>
//sets the value of the giveni index to the given value
//input: index of array and value to fill it with
void myArray<T>::setArr(int index, T value){
	if ((index >= 0) && (index < getSize())) {
        	arr[index] = value;
    	}
	else {
        	cout << "Array out of bounds" << endl;
	}
}
template <class T>
//sets the size of the array to a given input
//input: size of the array
void myArray<T>::setSize(int value) {
	if(value >=  0){
		size = value;
	}
	else{
		cout << "Size must be greater than or equal to 0" << endl;
	}
}
template <class T>
//inserats a value at the given index
//input: index to add the given value to
void myArray<T>::insert(int index, T value) {
	if(index > getSize()){
                cout << "index out of bounds" << endl;
                return;
        }
        T *tempArr = new T[size + 1];
        int i = 0;
        while(i < index){
                tempArr[i] = getArr(i);
                i++;
        }
        tempArr[i] = value;
        while(i < getSize()){
                tempArr[i + 1] = getArr(i);
                i++;
        }
     
	delete [] arr;
	setSize(getSize() + 1);
        arr = tempArr;
}
template <class T>
//removes value at given index
//input: index to remove from
void myArray<T>::remove(int index) {
	if(index >= getSize()){
                cout << "Array out of bounds" << endl;
                return;
        }
        while(index < getSize()){
		setArr(index, getArr(index + 1));
                index++;
        }
        setSize(getSize() - 1);

}
template <class T>
//gets value at given index
//input: index to get from
T myArray<T>::get(int index) const{
	if(index < getSize()){
                return getArr(index);
        }
        else{
                cout << "Array out of bounds" << endl;
                return -1;
        }
}
template <class T>
//sets all values to zero and sets size to 0
void myArray<T>::clear() {
	int i = 0;
        while(i < getSize()){
                setArr(i, 0);
                i++;
        }
        setSize(0);

}
template <class T>
//finds and returns index of given value
//input: value to search for
//output: index of the given value
int myArray<T>::find(T value) const{
	int i = 0;
        while(i < getSize()){
                if(value == getArr(i)){
                        return i;
                }
                i++;
        }
        return -1;
}
template <class T>
//determines if 2 arrays are equal
//input: array to compare to
//output: true if = false if not
bool myArray<T>::equals(T &rhs) const{
	bool result(true);
    	if (getSize() != rhs.getSize()) {
        	result = false;
    	}
	else {
        	for (int i = 0; i < getSize(); i++) {
           		if (getArr(i) != rhs.getArr(i)) {
                		result = false;
            		}
        	}
    	}
	return result;
}
template <class T>
//prints the values of the array
void myArray<T>::print() const{
	int i = 0;
	while(i < getSize()){
		cout << getArr(i) << " ";
		i++;
	}
}

template <class T>
//allows the user to populate the array
void myArray<T>::init() {
	int i = 0;
        T value;
        cout << "Please enter " << getSize() << " elements:" << endl;
        while(i < getSize()){
                cin >> value;
                setArr(i, value);
                i++;
        }
}
template <class T>
//sets the object equal to the given myArray
//input: myArray to set equal to
//output: reference to equal object
myArray<T>& myArray<T>::operator=(const myArray<T>& rhs){
	delete [] arr;
    	setSize(rhs.getSize());
    	arr = new T[getSize()];
    	int i = 0;
	while(i < getSize()){
		setArr(i, rhs.getArr(i));
		i++;
	}
	return *this;
}
template <class T>
//checks if 2 myArrays are equal
//input: myArray to compare to
//output: 1 if equal 0 if not
bool myArray<T>::operator==(const myArray<T>& rhs) const{
	bool result(true);

    	if (getSize() != rhs.getSize()) {
        	result = false;
    	}
 	else {
        	for (int i = 0; i < getSize(); i++) {
            		if (getArr(i) != rhs.getArr(i)) {
                	result = false;
            		}
        	}
    	}
	return result;
}
template <class T>
//checks if 2 myArrays are not equal
//input: myArray to compare to
//output: 0 if equal 1 if not
bool myArray<T>::operator!=(const myArray<T>& rhs) const{
	bool result(true);

        if (getSize() != rhs.getSize()) {
                result = false;
        }
        else {
                for (int i = 0; i < getSize(); i++) {
                        if (getArr(i) != rhs.getArr(i)) {
                        result = false;
                        }
                }
        }
        return !(result);

}
template <class T>
//returns a myArray object that contains the sum of this and a given object
//input: object to be summed
//output: myArray with an arr filled with the sum
const myArray<T> myArray<T>::operator+(const myArray<T>& rhs) const{
	myArray<T> temp(getSize() + rhs.getSize(), 0);
	int i = 0;
	while(i < getSize()){
		temp.setArr(i, getArr(i));
		i++;
	}
	int j = 0;
	while(j < rhs.getSize()){
		temp.setArr(i, rhs.getArr(j));
		i++;
		j++;
	}
	return temp;
}
template <class T>
//negates the values of arr
const myArray<T> myArray<T>::operator-(){
	myArray<T> temp(getSize(), 0);
	int i = 0;
	while(i < getSize()){
		temp.setArr(i, -(getArr(i)));
		i++;
	}
	return temp;
}
template <class T>
//increments the values of arr by 1 then outputs
//output: constant reference to adjusted object
const myArray<T>& myArray<T>::operator++(){
	int i = 0;
	while(i < getSize()){
		setArr(i, getArr(i) + 1);
		i++;
	}
	return *this;
}
template <class T>
//outputs values of arr then increments by 1
//output: constant myArray object before increment
const myArray<T> myArray<T>::operator++(int dummy){
	myArray<T> temp(getSize(), 0);
	int i = 0;
	while(i < getSize()){
		temp.setArr(i, getArr(i));
		i++;
	}
	i = 0;
	while(i < getSize()){
		setArr(i, getArr(i) + 1);
		i++;
	}
	return temp;	
}
template <class T>
//allows the user to call or set a value at an index
//input: index to be called
//output: reference to the value at index
T& myArray<T>::operator[](int index){
	if ((index >= 0) && (index < getSize())) {
        	return arr[index];
   	} 
	else {
		cout << "Array out of bounds" << endl;
        	return arr[index];
	}
}
template <class U>
//allows the user to use cout with the object
//input: myArray to be printed
ostream & operator<<(ostream& lhs, const myArray<U>& rhs){
	int i = 0;
	while(i < rhs.getSize()){
		lhs << rhs.getArr(i) << " ";
		i++;
	}
	cout << endl;
	return lhs;
}
template <class U>
//allows the user to use cin with the object
//input: myArray to be populated
istream & operator>>(istream& lhs, myArray<U>& rhs){
	int i = 0;
	double value = 0;
	while(i < rhs.getSize()){
		lhs >> value;
		rhs.setArr(i, value);
		i++;
	}
	return lhs;
}

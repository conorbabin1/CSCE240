/*
 * Created by: Conor Babin
 * Fri Sep 29 15:07:14 EDT 2017
 * input: *
 * output: *
 * File: myArray.h
*/

#include <iostream>
#include <cstdlib>
#include "myArray.h"

myArray::myArray() : size(0){
	arr = new double[size];
}

myArray::myArray(int _size, double num) : size(_size) {
	arr = new double[size];
	int i = 0;
	while(i < size){
		arr[i] = num;
		i++;
	}
}

myArray::myArray(double *_arr, int _size) : size(_size) {
	arr = new double[size];
	int i = 0;
	while(i < size){
		arr[i] = _arr[i];
		i++;
	}
}

myArray::~myArray() {
	delete [] arr;
}

double myArray::getArr(int index) {
	return arr[index];
}

int myArray::getSize() {
	return size;
}

void myArray::setArr(int index, double value){
	if ((index >= 0) && (index < getSize())) {
        	arr[index] = value;
    	}
	else {
        	cout << "Array out of bounds" << endl;
	}
}

void myArray::setSize(int value) {
	if(value >=  0){
		size = value;
	}
	else{
		cout << "Size must be greater than or equal to 0" << endl;
	}
}

void myArray::insert(int index, double value) {
	if(index > getSize()){
                cout << "index out of bounds" << endl;
                return;
        }
        double *tempArr = new double[size + 1];
        int i = 0;
        while(i < index){
                tempArr[i] = getArr(i);
                i++;
        }
        tempArr[i] = value;
        while(i < getSize()){
                tempArr[i + 1] = getArr(i);
                i++;
        }
     
	delete [] arr;
	setSize(getSize() + 1);
        arr = tempArr;
}

void myArray::remove(int index) {
	if(index >= getSize()){
                cout << "Array out of bounds" << endl;
                return;
        }
        while(index < getSize()){
		setArr(index, getArr(index + 1));
                index++;
        }
        setSize(getSize() - 1);

}

double myArray::get(int index) {
	if(index < getSize()){
                return getArr(index);
        }
        else{
                cout << "Array out of bounds" << endl;
                return -1;
        }
}

void myArray::clear() {
	int i = 0;
        while(i < getSize()){
                setArr(i, 0);
                i++;
        }
        setSize(0);

}

int myArray::find(double value) {
	int i = 0;
        while(i < getSize()){
                if(value == getArr(i)){
                        return i;
                }
                i++;
        }
        return -1;
}

bool myArray::equals(myArray &rhs) {
	bool result(true);
    	if (getSize() != rhs.getSize()) {
        	result = false;
    	}
	else {
        	for (int i = 0; i < getSize(); i++) {
           		if (getArr(i) != rhs.getArr(i)) {
                		result = false;
            		}
        	}
    	}
	return result;
}

void myArray::print() {
	int i = 0;
	while(i < getSize()){
		cout << getArr(i) << " ";
		i++;
	}
}

void myArray::init() {
	int i = 0;
        double value = 0;
        cout << "Please enter " << getSize() << " elements:" << endl;
        while(i < getSize()){
                cin >> value;
                setArr(i, value);
                i++;
        }
}

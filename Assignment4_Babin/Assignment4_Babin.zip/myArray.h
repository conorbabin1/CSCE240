/***************************************************************************
 * myArray class header file
 ***************************************************************************/
#ifndef MYARRAY_H
#define MYARRAY_H
#include <iostream>

using namespace std;
 
class myArray
{
	public: 
		myArray();
		myArray(int,double); 
		myArray(double*, int);
		~myArray();

		void setArr(int, double);
                int getSize();
                double getArr(int);
		void insert(int, double);
		void remove(int);
		double get(int);
		void clear();
		int find(double);
		bool equals(myArray&);
		void print();
		void init();
		
		
	private: 
		int size; 
		double *arr; 
		void setSize(int);
	
};

#endif

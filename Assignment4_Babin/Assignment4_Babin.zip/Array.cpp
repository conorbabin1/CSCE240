/*
 * Created by: Conor Babin
 * Fri Sep 29 15:07:14 EDT 2017
 * input: *
 * output: Version of ArrayList
 * File: Array.cpp
*/

#include <iostream>
#include <cstdlib>
#include "Array.h"

//default constructor
myArray::myArray() : size(0){
	arr = new double[size];
}

//alt constructor
//input: Array size and value to be populated
myArray::myArray(int _size, double num) : size(_size) {
	arr = new double[size];
	int i = 0;
	while(i < size){
		arr[i] = num;
		i++;
	}
}

//alt constructor
//input: pointer for Array and size of the array
myArray::myArray(double *_arr, int _size) : size(_size) {
	arr = new double[size];
	int i = 0;
	while(i < size){
		arr[i] = _arr[i];
		i++;
	}
}

//deconstructor
myArray::~myArray() {
	delete [] arr;
}

//gets given index of the array
//input: index
//output: value of the array at given index
double myArray::getArr(int index) {
	return arr[index];
}

//gets the size of the array
//output: size of the array
int myArray::getSize() {
	return size;
}

//sets the value of the giveni index to the given value
//input: index of array and value to fill it with
void myArray::setArr(int index, double value){
	if ((index >= 0) && (index < getSize())) {
        	arr[index] = value;
    	}
	else {
        	cout << "Array out of bounds" << endl;
	}
}

//sets the size of the array to a given input
//input: size of the array
void myArray::setSize(int value) {
	if(value >=  0){
		size = value;
	}
	else{
		cout << "Size must be greater than or equal to 0" << endl;
	}
}

//inserats a value at the given index
//input: index to add the given value to
void myArray::insert(int index, double value) {
	if(index > getSize()){
                cout << "index out of bounds" << endl;
                return;
        }
        double *tempArr = new double[size + 1];
        int i = 0;
        while(i < index){
                tempArr[i] = getArr(i);
                i++;
        }
        tempArr[i] = value;
        while(i < getSize()){
                tempArr[i + 1] = getArr(i);
                i++;
        }
     
	delete [] arr;
	setSize(getSize() + 1);
        arr = tempArr;
}

//removes value at given index
//input: index to remove from
void myArray::remove(int index) {
	if(index >= getSize()){
                cout << "Array out of bounds" << endl;
                return;
        }
        while(index < getSize()){
		setArr(index, getArr(index + 1));
                index++;
        }
        setSize(getSize() - 1);

}

//gets value at given index
//input: index to get from
double myArray::get(int index) {
	if(index < getSize()){
                return getArr(index);
        }
        else{
                cout << "Array out of bounds" << endl;
                return -1;
        }
}

//sets all values to zero and sets size to 0
void myArray::clear() {
	int i = 0;
        while(i < getSize()){
                setArr(i, 0);
                i++;
        }
        setSize(0);

}

//finds and returns index of given value
//input: value to search for
//output: index of the given value
int myArray::find(double value) {
	int i = 0;
        while(i < getSize()){
                if(value == getArr(i)){
                        return i;
                }
                i++;
        }
        return -1;
}

//determines if 2 arrays are equal
//input: array to compare to
//output: true if = false if not
bool myArray::equals(myArray &rhs) {
	bool result(true);
    	if (getSize() != rhs.getSize()) {
        	result = false;
    	}
	else {
        	for (int i = 0; i < getSize(); i++) {
           		if (getArr(i) != rhs.getArr(i)) {
                		result = false;
            		}
        	}
    	}
	return result;
}

//prints the values of the array
void myArray::print() {
	int i = 0;
	while(i < getSize()){
		cout << getArr(i) << " ";
		i++;
	}
}

//allows the user to populate the array
void myArray::init() {
	int i = 0;
        double value = 0;
        cout << "Please enter " << getSize() << " elements:" << endl;
        while(i < getSize()){
                cin >> value;
                setArr(i, value);
                i++;
        }
}

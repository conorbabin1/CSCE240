#include <cstdlib>
#include <iostream>
#include "Array.h"

using namespace std;



int main (int argc, char **argv)
{ 
//	cout << "**************Testing Default Constructor*****************" << endl;   
//	myArray A1;
//	cout << "A1: ";
//	A1.print();

//	cout << "**************Testing Alt Constructor 1*****************" << endl;	
//	myArray A2(5,0);
//	cout << "A2: "; 
//	A2.print();
	
//	cout << "**************Testing init*****************" << endl;	
//	A2.init();
//	cout << "A2 after init: "; 
//	A2.print();
	
//	int size = 5;	
//	double *temp = new double[size];
//	for(int i = 0; i < size; i++)
//	{
//		temp[i] = i;
//	}
	
//	cout << "**************Testing Alt Constructor 2*****************" << endl;	
//	myArray A3(temp, size); 
//	cout << "A3: "; 
//	A3.print();
	
//	cout << "**************Testing get*****************" << endl;
//	cout << "The element at index 0 is : " << A3.get(0) << endl;
//	cout << "The element at index 10 is : " << A3.get(10) << endl;
	
//	cout << "**************Testing insert*****************" << endl; 
//	A3.insert(5,7.5);
//	cout << "A3 after insert: " << endl;
//	A3.print();
	
//	cout << "**************Testing remove*****************" << endl; 
//	A3.remove(1);
//	cout << "A3 after remove: " << endl;
//	A3.print();
	
//	cout << "**************Testing find*****************" << endl; 
//	cout << "7.5 was found at index " << A3.find(7.5) << endl;
	
//	cout << "**************Testing equals*****************" << endl; 
//	bool ans = A2.equals(A3);
//	if(ans)
//	{
//		cout << "A2 equals A3." << endl;
//	}
//	else
//	{
//		cout << "A2 does not equal A3." << endl;
//	}
	
//	ans = A2.equals(A2); 
//	if(ans)
//	{
//		cout << "A2 equals A2." << endl;
//	}
//	else
//	{
//		cout << "A2 does not equal A2." << endl;
//	}
	
//	cout << "**************Testing clear*****************" << endl; 
//	A3.clear();
//	cout << "A3 after clear: " << endl;
//	A3.print();
	
//	A2.clear();
//	cout << "A2 after clear: " << endl;
//	A2.print();

	myArray a1(5, 0);
	myArray a2(5, 0);
	myArray a3(5, 0);
	a1.init();
	a2.init();
	a3.init();
	cout << "a1[0] = " << a1[0] << endl;
	cout << "==" << endl;
	cout << (a1 == a2) << endl;
	cout << "!=" << endl;
	cout << (a1 != a2) << endl;
	cout << "a3 = a1" << endl;
	cout << (a3 = a1) <<  endl;;
	cout << a3 << endl;	
	cout << "a1 + a2" << endl;
	cout << (a1 + a2) << endl;
	cout << "-" << endl;
	-a1;
	cout << a1 << endl;
	cout << "a1++" << endl;
	cout << a1++ << endl;
	cout << a1 << endl;
	cout << "++a1" << endl;
	cout << ++a1 << endl;	
  	cout << a1 << endl;
	cout << endl;
	myArray a4(5, 0);
	cin >> a4;
	cout << a4 << endl;
	cout << a3 << "  " << a1 << "  " << a2 << a4 << endl;
	cout << "+ cascade" << endl;
	cout << (a1 + a2 + a3 + a4) << endl;
	cout << a3 << "  " << a1 << "  " << a2 << a4 << endl;	
	cout << "= cascade" << endl;
	cout << (a3 = a1 = a2) << endl;
	cout << a3 << "  " << a1 << "  " << a2 << endl;
	cout << "make 5000" << endl;
	a1[2] = 5000;
	cout << a1; 
	return 0;
}























/*
 * Created by: Conor Babin
 * Fri Sep 29 15:07:14 EDT 2017
 * input: *
 * output: Version of ArrayList
 * File: Array.cpp
*/

#include <iostream>
#include <cstdlib>
#include "Array.h"

//default constructor
myArray::myArray() : size(0){
	arr = new double[size];
}

//alt constructor
//input: Array size and value to be populated
myArray::myArray(int _size, double num) : size(_size) {
	arr = new double[size];
	int i = 0;
	while(i < size){
		arr[i] = num;
		i++;
	}
}

//alt constructor
//input: pointer for Array and size of the array
myArray::myArray(double *_arr, int _size) : size(_size) {
	arr = new double[size];
	int i = 0;
	while(i < size){
		arr[i] = _arr[i];
		i++;
	}
}
//copy constructor
//input: myArray to copy
myArray::myArray(const myArray& orig) {
    setSize(orig.getSize());
    arr = new double[getSize()];
    for (int i = 0; i < getSize(); i++) {
        setArr(i, orig.getArr(i));
    }
}
//deconstructor
myArray::~myArray() {
	delete [] arr;
}

//gets given index of the array
//input: index
//output: value of the array at given index
double myArray::getArr(int index) const{
	return arr[index];
}

//gets the size of the array
//output: size of the array
int myArray::getSize() const{
	return size;
}

//sets the value of the giveni index to the given value
//input: index of array and value to fill it with
void myArray::setArr(int index, double value){
	if ((index >= 0) && (index < getSize())) {
        	arr[index] = value;
    	}
	else {
        	cout << "Array out of bounds" << endl;
	}
}

//sets the size of the array to a given input
//input: size of the array
void myArray::setSize(int value) {
	if(value >=  0){
		size = value;
	}
	else{
		cout << "Size must be greater than or equal to 0" << endl;
	}
}

//inserats a value at the given index
//input: index to add the given value to
void myArray::insert(int index, double value) {
	if(index > getSize()){
                cout << "index out of bounds" << endl;
                return;
        }
        double *tempArr = new double[size + 1];
        int i = 0;
        while(i < index){
                tempArr[i] = getArr(i);
                i++;
        }
        tempArr[i] = value;
        while(i < getSize()){
                tempArr[i + 1] = getArr(i);
                i++;
        }
     
	delete [] arr;
	setSize(getSize() + 1);
        arr = tempArr;
}

//removes value at given index
//input: index to remove from
void myArray::remove(int index) {
	if(index >= getSize()){
                cout << "Array out of bounds" << endl;
                return;
        }
        while(index < getSize()){
		setArr(index, getArr(index + 1));
                index++;
        }
        setSize(getSize() - 1);

}

//gets value at given index
//input: index to get from
double myArray::get(int index) const{
	if(index < getSize()){
                return getArr(index);
        }
        else{
                cout << "Array out of bounds" << endl;
                return -1;
        }
}

//sets all values to zero and sets size to 0
void myArray::clear() {
	int i = 0;
        while(i < getSize()){
                setArr(i, 0);
                i++;
        }
        setSize(0);

}

//finds and returns index of given value
//input: value to search for
//output: index of the given value
int myArray::find(double value) const{
	int i = 0;
        while(i < getSize()){
                if(value == getArr(i)){
                        return i;
                }
                i++;
        }
        return -1;
}

//determines if 2 arrays are equal
//input: array to compare to
//output: true if = false if not
bool myArray::equals(myArray &rhs) const{
	bool result(true);
    	if (getSize() != rhs.getSize()) {
        	result = false;
    	}
	else {
        	for (int i = 0; i < getSize(); i++) {
           		if (getArr(i) != rhs.getArr(i)) {
                		result = false;
            		}
        	}
    	}
	return result;
}

//prints the values of the array
void myArray::print() const{
	int i = 0;
	while(i < getSize()){
		cout << getArr(i) << " ";
		i++;
	}
}

//allows the user to populate the array
void myArray::init() {
	int i = 0;
        double value = 0;
        cout << "Please enter " << getSize() << " elements:" << endl;
        while(i < getSize()){
                cin >> value;
                setArr(i, value);
                i++;
        }
}
//sets the object equal to the given myArray
//input: myArray to set equal to
//output: reference to equal object
myArray& myArray::operator=(const myArray& rhs){
	delete [] arr;
    	setSize(rhs.getSize());
    	arr = new double[getSize()];
    	int i = 0;
	while(i < getSize()){
		setArr(i, rhs.getArr(i));
		i++;
	}
	return *this;
}
//checks if 2 myArrays are equal
//input: myArray to compare to
//output: 1 if equal 0 if not
bool myArray::operator==(const myArray& rhs) const{
	bool result(true);

    	if (getSize() != rhs.getSize()) {
        	result = false;
    	}
 	else {
        	for (int i = 0; i < getSize(); i++) {
            		if (getArr(i) != rhs.getArr(i)) {
                	result = false;
            		}
        	}
    	}
	return result;
}
//checks if 2 myArrays are not equal
//input: myArray to compare to
//output: 0 if equal 1 if not
bool myArray::operator!=(const myArray& rhs) const{
	bool result(true);

        if (getSize() != rhs.getSize()) {
                result = false;
        }
        else {
                for (int i = 0; i < getSize(); i++) {
                        if (getArr(i) != rhs.getArr(i)) {
                        result = false;
                        }
                }
        }
        return !(result);

}
//returns a myArray object that contains the sum of this and a given object
//input: object to be summed
//output: myArray with an arr filled with the sum
const myArray myArray::operator+(const myArray& rhs) const{
	myArray temp(rhs); 
    	if (getSize() != rhs.getSize()) {
        	cout << "Sizes do not match" << endl;
    	} 
	else {
        	for (int i = 0; i < getSize(); i++) {
            		temp.setArr(i, rhs.getArr(i) + getArr(i));
        	}
    	}
	return temp;
}
//negates the values of arr
void myArray::operator-(){
	int i = 0;
	while(i < getSize()){
		setArr(i, -(getArr(i)));
		i++;
	}
}
//increments the values of arr by 1 then outputs
//output: constant reference to adjusted object
const myArray& myArray::operator++(){
	int i = 0;
	while(i < getSize()){
		setArr(i, getArr(i) + 1);
		i++;
	}
	return *this;
}
//outputs values of arr then increments by 1
//output: constant myArray object before increment
const myArray myArray::operator++(int dummy){
	myArray temp(getSize(), 0);
	int i = 0;
	while(i < getSize()){
		temp.setArr(i, getArr(i));
		i++;
	}
	i = 0;
	while(i < getSize()){
		setArr(i, getArr(i) + 1);
		i++;
	}
	return temp;	
}
//allows the user to call or set a value at an index
//input: index to be called
//output: reference to the value at index
double& myArray::operator[](int index){
	if ((index >= 0) && (index < getSize())) {
        	return arr[index];
   	} 
	else {
		cout << "Array out of bounds" << endl;
        	return arr[index];
	}
}
//allows the user to use cout with the object
//input: myArray to be printed
ostream & operator<<(ostream& lhs, const myArray& rhs){
	int i = 0;
	while(i < rhs.getSize()){
		lhs << rhs.getArr(i) << " ";
		i++;
	}
	cout << endl;
	return lhs;
}
//allows the user to use cin with the object
//input: myArray to be populated
istream & operator>>(istream& lhs, myArray& rhs){
	int i = 0;
	double value = 0;
	while(i < rhs.getSize()){
		lhs >> value;
		rhs.setArr(i, value);
		i++;
	}
	return lhs;
}

/***************************************************************************
 * myArray class header file
 ***************************************************************************/
#ifndef ARRAY_H
#define ARRAY_H
#include <iostream>

using namespace std;
 
class myArray
{
	friend ostream & operator<<(ostream&, const myArray&);
        friend istream & operator>>(istream&, myArray&);

	public: 
		myArray();
		myArray(int,double); 
		myArray(double*, int);
		myArray(const myArray&);
		~myArray();

		void setArr(int, double);
                int getSize() const;
                double getArr(int) const;
		void insert(int, double);
		void remove(int);
		double get(int) const;
		void clear();
		int find(double) const;
		bool equals(myArray&) const;
		void print() const;
		void init();
		myArray& operator=(const myArray&);
		bool operator==(const myArray&) const;
		bool operator!=(const myArray&) const;
		const myArray operator+(const myArray&) const;
		void operator-();
		const myArray& operator++();
		const myArray operator++(int);
		double& operator[](int);
		
		
	private: 
		int size; 
		double *arr; 
		void setSize(int);
	
};

#endif
